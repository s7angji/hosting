package serial0217;

import java.util.EventListener;

public interface ArduinoEventListener extends EventListener {
	void arduinoEvent(ArduinoEvent event);
}
