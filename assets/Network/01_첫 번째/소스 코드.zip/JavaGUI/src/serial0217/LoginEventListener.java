package serial0217;

import java.util.EventListener;

public interface LoginEventListener extends EventListener {
	void loginEvent(LoginEvent event);
}
