package serial0217;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortList;

public class Arduino {
	public static final int CMD_NUM = 7;
	public static final String[] CMD_NAME = {
			"1. TV 켜기",
			"2. TV 끄기",
			"3. 스피커 동작",
			"4. 세탁기 동작",
			"5. 로그아웃 >_< ~!!",
			"6. 프로그램 종료", "7. 관리자 특별 모드 >_< ~!!"};

	public static final char TV_ON = '1';
	public static final char TV_OFF = '2';
	public static final char SPEAKER_ON = '3';
	public static final char CLEANER_ON = '4';
	public static final char LOGOUT = '5';
	public static final char PROGRAM_EXIT = '6';
	public static final char ADMIN_SETTING = '7';
	private boolean isAdmin;
	private static SerialPort serialPort = null;
	private ArduinoWindow window = null;
	public static SerialPort getSerialPortInstance() {
		if(serialPort == null) {
			// SerialPort 열기 !!
			String[] portName = SerialPortList.getPortNames();
			if(portName.length == 0) {
				JOptionPane.showMessageDialog(null, "아두이노가 연결되지 않았습니다. . .");
				System.exit(0);
			}
			serialPort = new SerialPort(portName[0]);
			try {
				serialPort.openPort();
				serialPort.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
			} catch (SerialPortException e) {
				e.printStackTrace();
			}
		}

		return serialPort;
	}
	public ArduinoWindow getArduinoWindow() {
		if(window == null)
			window = new ArduinoWindow();
		return window;
	}
	public Arduino(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	public void setAdminAndApplyToWindow(boolean isAdmin) {
		this.isAdmin = isAdmin;
		window.setEnabledAdminSetting(this.isAdmin);
	}

	
	
	
	
	public void runArduino() {

		// SerialPort 열기 !!
		Arduino.getSerialPortInstance();
		// 아두이노가 보내는 디버그 메세지를 받을려고 한당 !!
		new Thread(new ReadThread(serialPort)).start();

		window.addActionListenerInBtnCmd(Arduino.TV_ON - '1', new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					serialPort.writeInt(Arduino.TV_ON);
				} catch (SerialPortException exce) {
					exce.printStackTrace();
				}
			}
		});
		window.addActionListenerInBtnCmd(Arduino.TV_OFF - '1', new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					serialPort.writeInt(Arduino.TV_OFF);
				} catch (SerialPortException exce) {
					exce.printStackTrace();
				}
			}
		});
		window.addActionListenerInBtnCmd(Arduino.SPEAKER_ON - '1', new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					serialPort.writeInt(Arduino.SPEAKER_ON);
				} catch (SerialPortException exce) {
					exce.printStackTrace();
				}
			}
		});
		window.addActionListenerInBtnCmd(Arduino.CLEANER_ON - '1', new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					serialPort.writeInt(Arduino.CLEANER_ON);
				} catch (SerialPortException exce) {
					exce.printStackTrace();
				}
			}
		});
		window.addActionListenerInBtnCmd(Arduino.LOGOUT - '1', new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				fireArduinoEvent(new ArduinoEvent("로그아웃"));
			}
		});
		window.addActionListenerInBtnCmd(Arduino.PROGRAM_EXIT - '1', new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "프로그램 종료");
				System.exit(0);
			}
		});
		window.addActionListenerInBtnCmd(Arduino.ADMIN_SETTING - '1', new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "관리자권한 세팅들을 구현해주세요 :)");
			}
		});
	}


	private void fireArduinoEvent(ArduinoEvent event) {
		Object[] listeners = SerialMain.arduinoListenerList.getListenerList();

		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i] == ArduinoEventListener.class) {
				((ArduinoEventListener)listeners[i+1]).arduinoEvent(event);
			}
		}
	}
}

class ReadThread implements Runnable {
	SerialPort serial;
	public ReadThread(SerialPort serial) {
		this.serial = serial;
	}

	@Override
	public void run() {
		while (true) {
			try {
				byte[] read = serial.readBytes();
				if (read != null && read.length > 0) {
					System.out.print(new String(read));
				}
			} catch (SerialPortException e) {
				e.printStackTrace();
			}
		}

	}
}