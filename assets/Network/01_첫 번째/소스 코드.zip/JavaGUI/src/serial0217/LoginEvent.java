package serial0217;

import java.util.EventObject;

@SuppressWarnings("serial")
public class LoginEvent extends EventObject {
	public LoginEvent(Object source) {
		super(source);
	}
}