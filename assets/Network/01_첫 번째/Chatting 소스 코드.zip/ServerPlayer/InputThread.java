public class InputThread extends Thread {
	private final NioChatterServer cs;
	private final String s;

	public InputThread(NioChatterServer cs, String msg) {
		this.cs = cs;
		this.s = msg;
	}

	@Override
	public void run() {
		if(s.equals("quit"))
			cs.quit();
		else
			cs.sendBroadcastMessage(s);
	}
}