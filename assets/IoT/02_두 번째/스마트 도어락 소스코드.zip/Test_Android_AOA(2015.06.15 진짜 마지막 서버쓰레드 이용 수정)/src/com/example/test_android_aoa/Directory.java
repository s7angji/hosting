package com.example.test_android_aoa;

import java.io.OutputStream;

public class Directory {
	public OutputStream fileUri;
	boolean check = false;
}
